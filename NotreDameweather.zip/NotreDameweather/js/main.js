// Default location (area code or city, state – in quotes)
var lc = "South Bend, In";
// Really Simple Weather Plug-In Details
reallySimpleWeather.weather({
  wunderkey: '', // leave blank for Yahoo API
  location: lc, //your location here, also works in lat/lon
  woeid: '', // "Where on Earth ID" optional alternative to location
  unit: 'f', // 'c' also works
  success: function(weather) {
    // sample data to display city and temperature
    html='<main>';
    html+= '<section class="top">';
    html+= '<h1 class="wdata-01">'+weather.city+','+weather.region+'</h1>';
    html+= '<h2 class="wdata-02">'+weather.temp+'</h2>';
    html+= '<p class="wdata-03">' +weather.currently+' </p>'; 
    html+='</section>';
    html+='<section class="middle">';
    html+='<p> "Play Like a Champion Today Notre Dame Fighting Irish"</p>'
    html+='<section>';
    html+='<section class="bottom"> ';
    html+='<h3 class="wdata-04">'+weather.low+'</h3>';
    html+='<h3 class="wdata-05">'+weather.high+'</h3>';
    html+=‘';

html+='</section';
 
   
    html += '</main>';
  document.getElementById('weather').innerHTML = html;
  },
  error: function(error) {
  document.getElementById('weather').innerHTML = '<p>'+error+'</p>';
  }
});
